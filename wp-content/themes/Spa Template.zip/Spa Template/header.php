<!DOCTYPE html>
<html lang="en">
<head>
    <?php wp_head();?>
</head>
<body <?php body_class();?>> 
    <div class="pageContainer">
        <header>
            <!-- <div class="navbar-expand-md">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navCollapse" aria-controls="navCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <?php // wp_nav_menu(array('themeLocation' => 'topMenu', 'menu_class' => 'navbar collapse navbar-collapse navBar', 'menu_id' => 'navCollapse'));?> 
            </div> -->
        </header>
    
    
    
