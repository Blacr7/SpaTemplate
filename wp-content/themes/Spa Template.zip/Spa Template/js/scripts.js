$(document).ready(function(){
    console.log('testing');
})